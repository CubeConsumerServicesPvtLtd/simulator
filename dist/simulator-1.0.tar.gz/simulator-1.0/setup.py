from setuptools import setup

setup(
    name='simulator',
    version='1.0',
    scripts=['simulator'],
    install_requires=['python-dateutil']
)

